def affichtt():
    pygame.draw.rect(fenetre,(20,0,20),(0,0,800,800))
    fenetre.blit(ground,(0,600))
    if cptvag:
        if cptvag%2:t="vague "+str(vague)
        else:t=""
        texte=policescore.render(t,1,(255,255,255))
    else:
        t=str(scoreaff)
        texte=policescore.render(t,1,(255,255,255))
    fenetre.blit(texte,(360-len(t)*30,10))
    for i in particules:i.loop()
    joueur.afficher()
    for i in monstres:
        i.afficher()
    if cptpower<=0:fenetre.blit(poweruppng,(xpower*20,560-ypower*20))
    pygame.display.flip()
def signe(a):
    if a<0:return -1
    if a==0:return 0
    return 1
def distance(a,b):
    if a<b:return b-a
    else:return a-b
class particle:
    def __init__(self,x,y,numero,duree,color,trans,dirx,diry):
        self.x,self.y,self.numero,self.duree,self.color,self.trans,self.dirx,self.diry=x,y,numero,duree,color,trans,dirx,diry
    def loop(self):
        self.x+=self.dirx
        self.y+=self.diry
        self.duree-=1
        color=(self.color[0],self.color[1],self.color[2],self.duree*self.trans)
        pygame.draw.rect(fenetre,color,(self.x,self.y,10,10))
        if self.duree==0:
            for i in particules:
                if i.numero>self.numero:
                    i.numero-=1
            del particules[self.numero]
class ness:
    def __init__(self,x,y):
        self.x,self.y=x,y
        if personnage==1:self.costumes=[marpng,marpngg,marfairpng,marfairpngg,marhurtpng,marhurtpngg,maruairpng,maruairpngg,mardairpng,mardairpngg]
        elif personnage==2:self.costumes=[sonpng,sonpngg,sonfairpng,sonfairpngg,sonhurtpng,sonhurtpngg,sonuairpng,sonuairpngg,sondairpng,sondairpngg]
        elif personnage==4:self.costumes=[bowpng,bowpngg,bowfairpng,bowfairpngg,bowhurtpng,bowhurtpngg,bowuairpng,bowuairpngg,bowdairpng,bowdairpngg]
        elif personnage==5:self.costumes=[mewpng,mewpngg,mewfairpng,mewfairpngg,mewhurtpng,mewhurtpngg,mewuairpng,mewuairpngg,mewdairpng,mewdairpngg]
        elif personnage==3:self.costumes=[foxpng,foxpngg,foxfairpng,foxfairpngg,foxhurtpng,foxhurtpngg,foxuairpng,foxuairpngg,foxdairpng,foxdairpngg]
        else:self.costumes=[nespng,nespngg,nesfairpng,nesfairpngg,neshurtpng,neshurtpngg,nesuairpng,nesuairpngg,nesdairpng,nesdairpngg]
        self.costume,self.tb,self.direction=0,0,1
        self.fair,self.hurted,self.hurtx,self.hurty,self.uair,self.dair=0,0,0,0,0,0
        self.invincibilite,self.percent,self.defense=0,0,0
    def test(self):
        self.droite,self.gauche,self.espace,self.bas,self.haut=keys[K_RIGHT],keys[K_LEFT],(event.type==KEYDOWN and event.key==K_SPACE),keys[K_DOWN],keys[K_UP]
    def loop(self):
        global continuer,monstres,particules
        self.test()
        self.vitesse=1
        if self.hurted==0:
            if self.invincibilite>0:self.invincibilite-=1
            if self.y<=1:
                self.y,self.tb=1,1.5
                jumpwav.play()
                particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(134,144,154),10,2,-2))
                particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(134,144,154),10,-2,-2))
            self.y+=self.tb
            if self.tb<0 and self.bas:self.y-=0.15
            if self.fair:
                self.fair-=1
                self.vitesse=0.5
            elif self.uair:
                self.uair-=1
                self.vitesse=0.4
                self.tb-=0.02
                if personnage==3 and self.uair==15:self.tb=0.8
            elif self.dair:
                self.dair-=1
                self.vitesse=0.2
                if personnage==2 and self.dair>=5:
                    self.tb=0
                    self.vitesse=0.1
                    self.x+=self.direction
                    self.y-=1
                    if self.y<=1:
                        self.dair=1
                        self.y=1
                elif personnage==3 and self.dair>=8:
                    self.tb=0
                    self.x+=self.direction*1.5
                elif personnage==4 and self.dair>=8:
                    if self.y>1:
                        self.tb=-1.2
                        self.dair=12
                    else:self.dair=7
                elif personnage==5 and self.dair==3:
                    self.x+=self.direction*10
                    self.tb=0
            if self.droite:
                self.x+=stats[personnage][3]*self.vitesse
                if self.fair==0:self.direction=1
            elif self.gauche:
                self.x-=stats[personnage][3]*self.vitesse
                if self.fair==0:self.direction=-1
            if self.espace and self.fair==0 and self.uair==0 and (self.dair<=1 or personnage==3):
                self.fair,self.uair,self.dair=0,0,0
                if self.haut:
                    self.uair=stats[personnage][1][0]
                    if personnage==1:self.tb=1.2
                    elif personnage==3:self.tb=0
                elif self.bas:self.dair=stats[personnage][2][0]
                else:self.fair=stats[personnage][0][0]
            self.tb-=0.05
        else:
            self.hurted-=1
            self.y+=self.hurty*(0.8-self.defense*0.05+self.hurted*0.04)
            self.x+=self.hurtx*(0.8-self.defense*0.05+self.hurted*0.04)
            if self.haut:self.y+=0.15
            elif self.bas:self.y-=0.15
        if self.x<-1.5 or self.x>35.5 or self.y>=31:
            continuer=1
    def afficher(self):
        self.costume=0
        if self.fair>=stats[personnage][0][1]:self.costume=2
        elif self.hurted:self.costume=4
        elif self.uair>=stats[personnage][1][1]:self.costume=6
        elif self.dair>=stats[personnage][2][1]:self.costume=8
        self.costume+=(self.direction==-1)
        if self.invincibilite%2==0:fenetre.blit(self.costumes[self.costume],(self.x*20,560-self.y*20))
        a=self.percent
        if a>12:a=12
        pygame.draw.rect(fenetre,(255,255-a*18,255-a*20),(340,680,40,20))
        for i in range(self.defense):
            fenetre.blit(defenseiconepng,(10+i*36,660))
    def hurt(self,x,y,direction,force):
        global pause,continuer
        if self.invincibilite or self.hurted:return
        self.hurted,self.hurtx,self.hurty=6+force*2+self.percent,-1+2*(direction>0),0.2
        self.fair,self.uair,self.fair,self.tb=0,0,0,0
        self.invincibilite=20
        self.percent+=1
        hurtwav.play()
        pause=80+self.hurted*10
class monster:
    def __init__(self,x,y,direction,numero):
        self.x,self.y,self.direction,self.numero=x,y,direction,numero
        self.costume,self.costumes,self.tb,self.hurted=0,[monsterpng,monsterpng],0,0
        self.hurtx,self.hurty,self.poid,self.force,self.recompense=0,0,0,-1,1
    def loop(self):
        global particules
        if self.y<=1:
            if self.hurted:self.hurty*=-1
            else:self.y,self.tb=1,1.5
        if self.hurted==0:
            self.y+=self.tb
            self.x+=self.direction
            self.tb-=0.08
        else:
            self.y+=self.hurty*(0.8+self.hurted*0.04)
            self.x+=self.hurtx*(0.8+self.hurted*0.04)
            if self.hurted%2==0:particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(240,195,140),8,self.hurtx*0.7,self.hurty*0.7))
        self.ejection()
    def ejection(self):
        global score,scoreaff,pause,cptpower
        if self.hurted==0:
            for i in monstres:
                if i.hurted and distance(self.x,i.x)<2 and distance(self.y,i.y)<2:
                    self.hurted,self.hurtx,self.hurty=i.hurted+2,i.hurtx*1.2,i.hurty*1.2
                    hitwav.play()
                    pause=50
                    break
        else:
            if distance(self.x,xpower)<=distance(self.hurtx*2,0) and distance(self.y,ypower)<=5 and cptpower==0:cptpower=-1
        if self.y>=28 and self.hurted:
            soulevwav.play()
            score+=1
            scoreaff+=1
            for i in monstres:
                if i.numero>self.numero:
                    i.numero-=1
            del monstres[self.numero]
        if self.x<-1.5 or self.x>35.5:
            if self.hurted==0:self.direction*=-1
            else:
                soulevwav.play()
                goldgainwav.play()
                score+=1
                scoreaff+=self.recompense
                for i in monstres:
                    if i.numero>self.numero:
                        i.numero-=1
                del monstres[self.numero]
        if joueur.fair>=stats[personnage][0][1] and distance(self.x,joueur.x+joueur.direction*1.5)<stats[personnage][0][4] and distance(self.y,joueur.y)<stats[personnage][0][5]:
            self.hurted=14-self.poid
            self.tb=0
            hitwav.play()
            self.hurtx,self.hurty=joueur.direction*stats[personnage][0][2],stats[personnage][0][3]
            self.poid-=1
            self.x=joueur.x+joueur.direction*(stats[personnage][0][4]+0.5)
            pause=50
        elif joueur.uair>=stats[personnage][1][1] and distance(self.x,joueur.x)<stats[personnage][1][4] and distance(self.y,joueur.y+1.5)<stats[personnage][1][5]:
            self.hurted=11-self.poid
            hitwav.play()
            joueur.tb=0
            self.tb=0
            self.hurtx,self.hurty=stats[personnage][1][2]*joueur.direction,stats[personnage][1][3]
            self.tb=0
            self.poid-=2
            pause=50
        elif joueur.dair>=stats[personnage][2][1] and distance(self.x,joueur.x)<stats[personnage][2][4] and distance(self.y,joueur.y-1)<stats[personnage][2][5]:
            self.hurted=stats[personnage][2][7]-self.poid//2
            hitwav.play()
            joueur.dair=8
            self.tb=0
            self.hurtx,self.hurty=stats[personnage][2][2]*joueur.direction,stats[personnage][2][3]
            self.poid-=2
            pause=50
            if personnage==2:joueur.dair=5
        elif distance(self.x,joueur.x)<1.5 and distance(self.y,joueur.y)<1.5 and self.hurted==0:
            joueur.hurt(self.x,self.y,self.direction,self.force)
        if self.hurted:self.hurted-=1
    def afficher(self):
        self.costume=(self.direction<0)
        fenetre.blit(self.costumes[self.costume],(self.x*20,560-self.y*20))
class demon(monster):
    def __init__(self,x,y,direction,numero):
        self.x,self.y,self.direction,self.numero=x,y,direction,numero
        self.costume,self.costumes,self.tb,self.hurted=0,[demonpng,demonpngg],0,0
        self.hurtx,self.hurty,self.poid,self.force,self.recompense=0,0,3,2,2
    def loop(self):
        if self.y<=1:
            if self.hurted:self.hurty*=-1
            else:self.y,self.tb=1,2
        if self.hurted==0:
            self.y+=self.tb
            self.x+=self.direction
            self.tb-=0.1
        else:
            self.y+=self.hurty*(0.8+self.hurted*0.04)
            self.x+=self.hurtx*(0.8+self.hurted*0.04)
            if self.hurted%2==0:particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(200,45,90),8,self.hurtx*0.7,self.hurty*0.7))
        self.ejection()
class robot(monster):
    def __init__(self,x,y,direction,numero):
        self.x,self.y,self.direction,self.numero=x,y,direction,numero
        self.costume,self.costumes,self.tb,self.hurted=0,[robotpng,robotpngg],0,0
        self.hurtx,self.hurty,self.poid,self.force,self.recompense=0,0,4,1,2
    def loop(self):
        if self.y<=1:
            if self.hurted:self.hurty*=-1
            else:self.y,self.tb=1,1.5
        if self.hurted==0:
            self.y+=self.tb
            self.x+=self.direction
            self.tb-=0.06
        else:
            self.y+=self.hurty*(0.8+self.hurted*0.04)
            self.x+=self.hurtx*(0.8+self.hurted*0.04)
            if self.hurted%2==0:particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(200,45,90),8,self.hurtx*0.7,self.hurty*0.7))
        self.ejection()
class ninja(monster):
    def __init__(self,x,y,direction,numero):
        self.x,self.y,self.direction,self.numero=x,y,direction,numero
        self.costume,self.costumes,self.tb,self.hurted=0,[ninjapng,ninjapngg],0,0
        self.hurtx,self.hurty,self.poid,self.force,self.recompense=0,0,3,2,3
        self.cpt=40
    def loop(self):
        if self.y<=1:
            if self.hurted:self.hurty*=-1
            else:self.y,self.tb=1,1.5
        if self.hurted==0:
            self.cpt-=1
            self.y+=self.tb
            if self.cpt<=15:self.x+=self.direction*2
            else:self.x+=self.direction
            if self.cpt==0:self.cpt=100
            self.tb-=0.06
        else:
            self.y+=self.hurty*(0.8+self.hurted*0.04)
            self.x+=self.hurtx*(0.8+self.hurted*0.04)
            if self.hurted%2==0:particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(200,45,90),8,self.hurtx*0.7,self.hurty*0.7))
        self.ejection()
class knight(monster):
    def __init__(self,x,y,direction,numero):
        self.x,self.y,self.direction,self.numero=x,y,direction,numero
        self.costume,self.costumes,self.tb,self.hurted=0,[knightpng,knightpngg],0,0
        self.hurtx,self.hurty,self.poid,self.force,self.recompense=0,0,4,1,3
        self.cpt=40
    def loop(self):
        if self.y<=1:
            if self.hurted:self.hurty*=-1
            else:self.y,self.tb=1,1.5
        if self.hurted==0:
            self.cpt-=1
            if self.cpt<=10:
                self.tb+=0.05
            if self.cpt==0:self.cpt=90
            self.y+=self.tb
            self.x+=self.direction
            self.tb-=0.06
        else:
            self.y+=self.hurty*(0.8+self.hurted*0.04)
            self.x+=self.hurtx*(0.8+self.hurted*0.04)
            if self.hurted%2==0:particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(120,130,140),8,self.hurtx*0.7,self.hurty*0.7))
        self.ejection()
class king(monster):
    def __init__(self,x,y,direction,numero):
        self.x,self.y,self.direction,self.numero=x,y,direction*1.2,numero
        self.costume,self.costumes,self.tb,self.hurted=0,[kingpng,kingpngg],0,0
        self.hurtx,self.hurty,self.poid,self.force,self.recompense=0,0,5,3,5
    def loop(self):
        if self.y<=1:
            if self.hurted:self.hurty*=-1
            else:self.y,self.tb=1,2.5
        if self.hurted==0:
            self.y+=self.tb
            self.x+=self.direction
            self.tb-=0.15
        else:
            self.y+=self.hurty*(0.8+self.hurted*0.04)
            self.x+=self.hurtx*(0.8+self.hurted*0.04)
            if self.hurted%2==0:particules.append(particle(self.x*20+30,610-self.y*20,len(particules),10,(200,45,90),8,self.hurtx*0.7,self.hurty*0.7))
        self.ejection()
import pygame,random
from pygame.locals import *
pygame.init()
path="ressource/"
ground=pygame.image.load(path+"ground.png")
youlostpng=pygame.image.load(path+"you lost.png")
chooseyourstarter=pygame.image.load(path+"chooseyourstarter.jpg")
nespng=pygame.image.load(path+"nes.png")
nespngg=pygame.image.load(path+"nesg.png")
nesfairpng=pygame.image.load(path+"nesfair.png")
nesfairpngg=pygame.image.load(path+"nesfairg.png")
neshurtpng=pygame.image.load(path+"neshurt.png")
neshurtpngg=pygame.image.load(path+"neshurtg.png")
nesuairpng=pygame.image.load(path+"nesuair.png")
nesuairpngg=pygame.image.load(path+"nesuairg.png")
nesdairpng=pygame.image.load(path+"nesdair.png")
nesdairpngg=pygame.image.load(path+"nesdairg.png")
marpng=pygame.image.load(path+"mar.png")
marpngg=pygame.image.load(path+"marg.png")
marfairpng=pygame.image.load(path+"marfair.png")
marfairpngg=pygame.image.load(path+"marfairg.png")
marhurtpng=pygame.image.load(path+"marhurt.png")
marhurtpngg=pygame.image.load(path+"marhurtg.png")
maruairpng=pygame.image.load(path+"maruair.png")
maruairpngg=pygame.image.load(path+"maruairg.png")
mardairpng=pygame.image.load(path+"mardair.png")
mardairpngg=pygame.image.load(path+"mardairg.png")
sonpng=pygame.image.load(path+"son.png")
sonpngg=pygame.image.load(path+"song.png")
sonfairpng=pygame.image.load(path+"sonfair.png")
sonfairpngg=pygame.image.load(path+"sonfairg.png")
sonhurtpng=pygame.image.load(path+"sonhurt.png")
sonhurtpngg=pygame.image.load(path+"sonhurtg.png")
sonuairpng=pygame.image.load(path+"sonuair.png")
sonuairpngg=pygame.image.load(path+"sonuairg.png")
sondairpng=pygame.image.load(path+"sondair.png")
sondairpngg=pygame.image.load(path+"sondairg.png")
foxpng=pygame.image.load(path+"fox.png")
foxpngg=pygame.image.load(path+"foxg.png")
foxfairpng=pygame.image.load(path+"foxfair.png")
foxfairpngg=pygame.image.load(path+"foxfairg.png")
foxhurtpng=pygame.image.load(path+"foxhurt.png")
foxhurtpngg=pygame.image.load(path+"foxhurtg.png")
foxuairpng=pygame.image.load(path+"foxuair.png")
foxuairpngg=pygame.image.load(path+"foxuairg.png")
foxdairpng=pygame.image.load(path+"foxdair.png")
foxdairpngg=pygame.image.load(path+"foxdairg.png")
bowpng=pygame.image.load(path+"bow.png")
bowpngg=pygame.image.load(path+"bowg.png")
bowfairpng=pygame.image.load(path+"bowfair.png")
bowfairpngg=pygame.image.load(path+"bowfairg.png")
bowhurtpng=pygame.image.load(path+"bowhurt.png")
bowhurtpngg=pygame.image.load(path+"bowhurtg.png")
bowuairpng=pygame.image.load(path+"bowuair.png")
bowuairpngg=pygame.image.load(path+"bowuairg.png")
bowdairpng=pygame.image.load(path+"bowdair.png")
bowdairpngg=pygame.image.load(path+"bowdairg.png")
mewpng=pygame.image.load(path+"mew.png")
mewpngg=pygame.image.load(path+"mewg.png")
mewfairpng=pygame.image.load(path+"mewfair.png")
mewfairpngg=pygame.image.load(path+"mewfairg.png")
mewhurtpng=pygame.image.load(path+"mewhurt.png")
mewhurtpngg=pygame.image.load(path+"mewhurtg.png")
mewuairpng=pygame.image.load(path+"mewuair.png")
mewuairpngg=pygame.image.load(path+"mewuairg.png")
mewdairpng=pygame.image.load(path+"mewdair.png")
mewdairpngg=pygame.image.load(path+"mewdairg.png")
monsterpng=pygame.image.load(path+"monster.png")
demonpng=pygame.image.load(path+"demon.png")
demonpngg=pygame.image.load(path+"demong.png")
knightpng=pygame.image.load(path+"knight.png")
knightpngg=pygame.image.load(path+"knightg.png")
robotpng=pygame.image.load(path+"robot.png")
robotpngg=pygame.image.load(path+"robotg.png")
ninjapng=pygame.image.load(path+"ninja.png")
ninjapngg=pygame.image.load(path+"ninjag.png")
kingpng=pygame.image.load(path+"king.png")
kingpngg=pygame.image.load(path+"kingg.png")
playpng=pygame.image.load(path+"play.png")
buypng=pygame.image.load(path+"buy.png")
poorpng=pygame.image.load(path+"poor.png")
arrowpng=pygame.image.load(path+"arrow.png")
poweruppng=pygame.image.load(path+"powerup.png")
defenseiconepng=pygame.image.load(path+"defenseicone.png")
jumpwav=pygame.mixer.Sound(path+"jump.wav")
goldgainwav=pygame.mixer.Sound(path+"goldgain.wav")
hitwav=pygame.mixer.Sound(path+"hit.wav")
soulevwav=pygame.mixer.Sound(path+"soulev.wav")
hurtwav=pygame.mixer.Sound(path+"hurt.wav")
music=pygame.mixer.Sound(path+"SpiritualBattle.ogg")
continuer=2
icones=[nespng,marpng,sonpng,foxpng,bowpng,mewpng]
horloge=pygame.time.Clock()
policescore=pygame.font.Font(path+"3dpolice.ttf",80)
policeargent=pygame.font.Font(None,30)
fenetre=pygame.display.set_mode((720,720))
fullscreen=0
gold=0
personnage=5
prix=[50,50,180,50,180,500]
fullscreen=0
stats=[[[15,6,1.5,0.1,1.5,2],[12,4,0,1.1,1.5,2,1.5],[11,6,0.6,0.6,1.5,2,-1.5,12],0.5],[[15,8,1.2,0,2.2,2.5],[20,10,0.2,1.2,1.5,2.2,2],[11,6,0.5,0.8,2,2.6,-1,12],0.5],[[16,5,1.3,0.1,1.6,1.8],[10,3,0,0.8,1.5,2,1.5],[12,5,1.2,-1.2,2.5,2.5,0,14],0.6],[[14,6,1.5,0.1,1.4,2.2],[18,10,0,1.5,2,3,0],[15,8,1.2,0.6,2,1.5,0,10],0.5],[[18,8,1.7,0.15,1.3,2.2],[15,6,0.2,1.4,1.5,2,1.5],[11,8,0.4,-2.2,1.5,2,-1.5,14],0.45],[[15,5,1.6,0.15,1.5,2],[12,4,0.2,1.2,1.5,2,1.7],[6,2,0.4,0.4,2,2,0,10],0.55]]
try:
    choix=1
    while continuer==2:
        horloge.tick(15)
        event=pygame.event.poll()
        fenetre.blit(chooseyourstarter,(0,0))
        fenetre.blit(arrowpng,(70+choix*230,100))
        if event.type==QUIT or(event.type==KEYDOWN and event.key==K_ESCAPE):continuer=0
        elif event.type==KEYDOWN and event.key==K_f:
            if fullscreen:pygame.display.set_mode((800,800))
            else:pygame.display.set_mode((800,800), FULLSCREEN)
            fullscreen=(fullscreen+1)%2
        elif event.type==KEYDOWN and event.key==K_SPACE:continuer=1
        elif event.type==KEYDOWN and event.key==K_RIGHT:choix=(choix+1)%3
        elif event.type==KEYDOWN and event.key==K_LEFT:choix=(choix-1)%3
        pygame.display.flip()
    if choix==2:choix=3
    personnage=choix
    prix[choix]=0
    while continuer:
        continuer=2
        monstrestypes=[monster,[demon,robot][random.randint(0,1)],[knight,ninja][random.randint(0,1)],king]
        cpt,pause=60,0
        score,scoreaff=0,0
        joueur=ness(18,1)
        music.play(-1)
        monstres,particules=[],[]
        vague,cptvag,xpower,ypower,cptpower,dirpower,pausee=0,60,0,0,200,0,0
        while continuer==2:
            horloge.tick(30)
            if event.type==QUIT or(event.type==KEYDOWN and event.key==K_ESCAPE):continuer=0
            elif event.type==KEYDOWN and event.key==K_f:
                if fullscreen:pygame.display.set_mode((800,800))
                else:pygame.display.set_mode((800,800), FULLSCREEN)
                fullscreen=(fullscreen+1)%2
            if pause:
                pygame.time.wait(pause)
                pause=0
            event=pygame.event.poll()
            keys=pygame.key.get_pressed()
            if pausee:
                if event.type==KEYDOWN and event.key==K_p:pausee=0
                else:continue
            elif event.type==KEYDOWN and event.key==K_p:pausee=1
            for i in monstres:i.loop()
            joueur.loop()
            affichtt()
            if cptpower==-1:
                xpower+=dirpower*0.4
                if xpower<-1.5 or xpower>35.5:cptpower=250
                elif distance(joueur.x,xpower)<=4 and distance(joueur.y,ypower)<=4:
                    cptpower=250
                    if joueur.defense<=8:joueur.defense+=1
                    else:
                        scoreaff+=15
                        goldgainwav.play(8)
            elif cptpower>=2:cptpower-=1
            elif cptpower:
                cote=random.randint(0,1)
                xpower=33*cote
                ypower=random.randint(14,17+(score>=15)*4)
                dirpower=(-1+cote*2)*-1
                cptpower=0
            if score+len(monstres)>=vague*30:
                if len(monstres)==0:
                    scoreaff+=vague*10
                    vague+=1
                    cptvag=60
                    joueur.percent//=2
            elif cptvag:cptvag-=1
            elif len(monstres)<=6:cpt-=1
            if cpt==0:
                cpt=int((random.randint(68-score//3,72-score//3)+len(monstres)*4)*(0.8+vague/4))
                if cpt<=10:cpt=10
                cote=random.randint(0,1)
                for i in range(vague):
                    if score+len(monstres)>=vague*30:break
                    typ=random.randint(score,score+20)//25
                    if typ>3:typ=3
                    cpt+=typ*28
                    monstres.append(monstrestypes[typ](-1+36*cote,random.randint(1,5)+(i//2)*4,(-1+cote*2)/random.randint(3,5),len(monstres)))
                    cote=(cote+1)%2
        music.stop()
        gold+=scoreaff
        while continuer==1:
            horloge.tick(30)
            event=pygame.event.poll()
            if event.type==QUIT or(event.type==KEYDOWN and event.key==K_ESCAPE):continuer=0
            elif event.type==KEYDOWN and event.key==K_f:
                if fullscreen:pygame.display.set_mode((800,800))
                else:pygame.display.set_mode((800,800), FULLSCREEN)
                fullscreen=(fullscreen+1)%2
            elif event.type==KEYDOWN:continuer=2
            fenetre.blit(youlostpng,(0,0))
            t=str(scoreaff)
            texte=policescore.render(t,1,(255,255,255))
            fenetre.blit(texte,(360-len(t)*40,300))
            pygame.display.flip()
        if continuer==2:continuer=1
        while continuer==1:
            horloge.tick(30)
            event=pygame.event.poll()
            if event.type==QUIT or(event.type==KEYDOWN and event.key==K_ESCAPE):continuer=0
            elif event.type==KEYDOWN and event.key==K_f:
                if fullscreen:pygame.display.set_mode((800,800))
                else:pygame.display.set_mode((800,800), FULLSCREEN)
                fullscreen=(fullscreen+1)%2
            elif event.type==KEYDOWN and event.key==K_SPACE:
                if prix[personnage]==0:continuer=2
                elif prix[personnage]<=gold:
                    gold-=prix[personnage]
                    prix[personnage]=0
            elif event.type==KEYDOWN and event.key==K_RIGHT:personnage=(personnage+1)%6
            elif event.type==KEYDOWN and event.key==K_LEFT:personnage=(personnage-1)%6
            pygame.draw.rect(fenetre,(20,0,20),(0,0,720,720))
            fenetre.blit(icones[personnage],(320,240))
            if prix[personnage]==0:fenetre.blit(playpng,(300,440))
            elif prix[personnage]<=gold:
                fenetre.blit(buypng,(300,440))
                texte=policeargent.render(str(prix[personnage]),1,(250,250,250))
                fenetre.blit(texte,(330,450))
            else:
                fenetre.blit(poorpng,(300,440))
                texte=policeargent.render(str(prix[personnage]),1,(250,250,250))
                fenetre.blit(texte,(330,450))
            t=str(gold)
            texte=policescore.render(t,1,(255,255,255))
            fenetre.blit(texte,(360-len(t)*40,10))
            pygame.display.flip()
except:pass
pygame.quit()
